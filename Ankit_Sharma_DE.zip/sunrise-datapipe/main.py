import requests
import json
import webbrowser
import requests
from datetime import date, timedelta
import csv
import function_def
from pyspark.sql import SparkSession
import function_def
import json

today = date.today()

f = r"https://api.sunrise-sunset.org/json?"

if __name__ == '__main__':
    z = []
    function_def.load_data_to_csv(f, z)
