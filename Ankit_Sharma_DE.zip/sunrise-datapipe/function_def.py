import requests
from datetime import date, timedelta
import csv
import json
import os


def incremental_load(df):
    url = "jdbc:sqlite:test.db"
    df.write.jdbc(url=url, table="test", mode="append", properties={"driver": "org.sqlite.JDBC"})


def historical_load(df):
    url = "jdbc:sqlite:test.db"
    df.write.jdbc(url=url, table="test", mode="overwrite", properties={"driver": "org.sqlite.JDBC"})


'''full data load to csv'''


def load_data_to_csv(f, z):
    if os.stat("file").st_size == 0:
        start_date = date(2020, 1, 1)
        end_date = date.today()
        for single_date in daterange(start_date, end_date + 1):
            d = single_date.strftime("%Y-%m-%d")
            params = {"lat": 18.5204, "lng": 73.8567, "date": d}
            a = requests.get(f, params=params)
            a = json.loads(a.text)
            a = a["results"]
            z.append(list((a["sunrise"], a["sunset"], a["day_length"])))
            save_data_to_csv(z)
    else:
        a = requests.get('https://api.sunrise-sunset.org/json?lat=36.7201600&lng=-4.4203400&date=today')
        a = json.loads(a.text)
        a = a["results"]
        z.append(list((a["sunrise"], a["sunset"], a["day_length"])))

        save_data_to_csv(z)
    return 0;


'''loop for iterate over date for historical data load'''


def daterange(start_date, end_date):
    for n in range(int((end_date - start_date).days)):
        yield start_date + timedelta(n)


def save_data_to_csv(z):
    with open('Data.csv', 'w') as f:
        fields = ['sunrise', 'sunset', 'day_length']
        # using csv.writer method from CSV package
        write = csv.writer(f)
        write.writerow(fields)
        write.writerows(z)
