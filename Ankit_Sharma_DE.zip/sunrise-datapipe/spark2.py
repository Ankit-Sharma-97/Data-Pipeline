import pyspark
from pyspark.shell import sc
from pyspark.sql import SparkSession
import  function_def
import json

import pyspark
from pyspark.sql import SparkSession
from pyspark.sql.functions import from_utc_timestamp

spark = SparkSession.builder.appName("Load Tables")\
    .config("spark.executor.extraClassPath","C:\\spark-setup\\spark\\jars\\mysql-connector-java-8.0.27.jar")\
    .config("spark.driver.extraClassPath","C:\\spark-setup\\spark\\jars\\mysql-connector-java-8.0.27.jar")\
    .getOrCreate()

df=spark.read.csv("data.csv")
df1 = (df
    .select("sunshine", "sunset","day_length")
    .withColumn("sunshine_ist", from_utc_timestamp("sunshine", "IST")) \
    .withColumn("sunset_ist", from_utc_timestamp("sunset", "IST")))
df1.show()
if df1.count()>1:
    function_def.historical_load(df1)
else:
    function_def.incremental_load(df1)
